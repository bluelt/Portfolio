package MockModule.controller;

public class AuthedAPIController extends APIController {

}
