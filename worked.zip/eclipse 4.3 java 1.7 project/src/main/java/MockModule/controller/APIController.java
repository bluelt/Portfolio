package MockModule.controller;

import org.springframework.stereotype.Controller;

@Controller
public class APIController {

	protected APIRequestValidator apiRequestValidator;
}
