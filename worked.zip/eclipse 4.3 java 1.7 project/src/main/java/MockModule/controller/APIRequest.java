package MockModule.controller;

public interface APIRequest {

	void validate();
}
