package MockModule.controller;

public interface WebDefine {
	
		public static final String N_SESSION_INFO = "";
}
