package MockModule.domain;

public class AuthedSessionInfo {

	public String getUserId() {
		return null;
	}

	public String getDeviceId() {
		return null;
	}
	
}
