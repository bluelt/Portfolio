package MockModule.util.validator;

public class StringValidator {
	
	public static boolean isValidString( String str ) {
		return false;
	}
	
	public static boolean isPhoneNumberString( String phoneNumber ) {
		return false;
	}

	public static boolean isEmailString( String email ) {
		return false;
	}
}
