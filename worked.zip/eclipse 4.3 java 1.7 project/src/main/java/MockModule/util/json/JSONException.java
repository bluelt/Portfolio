package MockModule.util.json;

public class JSONException extends Exception {

	private static final long serialVersionUID = 0;
}
