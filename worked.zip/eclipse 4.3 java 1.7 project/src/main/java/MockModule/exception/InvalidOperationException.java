package MockModule.exception;


public class InvalidOperationException extends PolarisException {

	private static final long serialVersionUID = 7096066441758640177L;

	public InvalidOperationException() {
	}
}
