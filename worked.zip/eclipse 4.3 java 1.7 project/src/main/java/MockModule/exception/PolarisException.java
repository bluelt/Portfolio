package MockModule.exception;


public class PolarisException extends RuntimeException {

	private static final long serialVersionUID = -1985883349112106943L;

	public PolarisException() {
	}

}
