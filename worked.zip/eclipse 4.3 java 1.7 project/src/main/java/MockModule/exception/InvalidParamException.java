package MockModule.exception;


public class InvalidParamException extends PolarisException {

	private static final long serialVersionUID = -9028357475149599086L;

	public InvalidParamException() {
	}
}
