package PortfolioModule.exception.friend;

import MockModule.exception.PolarisException;

public class FriendAPIAttributeViolationException extends PolarisException {

	private static final long serialVersionUID = -2360947985703754066L;

}
