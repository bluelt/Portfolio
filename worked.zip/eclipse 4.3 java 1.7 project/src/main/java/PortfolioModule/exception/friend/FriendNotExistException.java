package PortfolioModule.exception.friend;

import MockModule.exception.PolarisException;

public class FriendNotExistException extends PolarisException {

	private static final long serialVersionUID = -847769887045950774L;

}
