package PortfolioModule.test.api.friend;

import org.junit.Before;
import org.junit.Test;

public class FriendAPITest {
	
	@Before
	public void setUp() {

	}

	@Test
	public void friend_getattribute() {

	}
	
	@Test
	public void friend_revision() {

	}
	
	@Test
	public void friend_list() {
	}
	
	@Test(timeout=30000)
	public void friend_changedlist_on_add() {
	}
	
	@Test
	public void friend_changedlist_optimize() {

	}
	
	@Test
	public void friend_changedlist_excess_max_diff() {
	
	}
	
	@Test
	public void friend_update_concurrency() throws InterruptedException {

	}

	@Test
	public void friend_delete_last_send_time() {
	
	}
	
	@Test
	public void friend_exceess_max_update_count() {

	}
	
	@Test
	public void friend_addbynumber() {

	}
	
	@Test
	public void friend_hide_and_show() {
	
	}
	
	@Test
	public void friend_add() {

	}
}
